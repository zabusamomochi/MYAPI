let users = [{
    id: 1,
    nome: "juninho",
    email: "juninho@gmail.com",
    senha: "424256"

},
{
    id: 2,
    nome: "silvana",
    email: "silvana@hotmail.com",
    senha: "412464"
},
{
    id: 10,
    nome: "Ezio",
    email: "Dafirenze_10@gmail.com",
    senha: "123456"

}];

module.exports = users;

